bl_info = {
    "name": "English Ukraine",
    "author": "ChatGPT",
    "version": (1, 0),
    "blender": (3, 4, 0),
    "description": "Switch Interface Language",
    "category": "System",
}

import bpy

class LanguageToggleOperator(bpy.types.Operator):
    """Toggle between Ukrainian and English interface languages"""
    bl_idname = "wm.language_toggle"
    bl_label = "Toggle Language"

    def execute(self, context):
        view_prefs = context.preferences.view
        # If the current language is Ukrainian, switch to English
        if view_prefs.language == "uk_UA":
            view_prefs.language = "en_US"
        # If the current language is not Ukrainian, switch to Ukrainian
        else:
            view_prefs.language = "uk_UA"

        return {'FINISHED'}

addon_keymaps = []

def register():
    bpy.utils.register_class(LanguageToggleOperator)

    # Add the keymap
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Window', space_type='EMPTY', region_type='WINDOW')
        kmi = km.keymap_items.new(LanguageToggleOperator.bl_idname, type='X', value='PRESS', ctrl=True)
        addon_keymaps.append((km, kmi))

def unregister():
    bpy.utils.unregister_class(LanguageToggleOperator)

    # Remove the keymap
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps:
            km.keymap_items.remove(kmi)
        addon_keymaps.clear()

if __name__ == "__main__":
    register()
